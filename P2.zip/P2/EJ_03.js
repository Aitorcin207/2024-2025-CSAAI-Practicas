console.log("La página ya está cargada")
console.log("Ahora es seguro ejecutar el código js")
console.log("defer....")